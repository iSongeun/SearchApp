//
//  ViewController.swift
//  SearchApp
//
//  Created by 이송은 on 2022/11/28.
//

import UIKit
import RxSwift
class ViewController: UIViewController {
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        test1()
    }

    func test1(){
        print("-----startwith")
        let children = Observable<String>.of("0","1","2")
        
            //enumnerated - element와 index 분리
        children.enumerated().map { index , element in
            element + "어린이" + "\(index)"
            
        }.startWith("teacher").subscribe(onNext : {
          print($0)
        }).disposed(by: disposeBag)
        
        print("-----concat1")
        let teacher = Observable<String>.of("teacher")
        let lineWalking = Observable.concat([teacher,children])
        
        lineWalking.subscribe(onNext : {
            print($0)
        }).disposed(by: disposeBag)
        
        print("-----concat2")
        teacher.concat(children).subscribe(onNext: {
            print($0)
        }).disposed(by: disposeBag)
        
        print("-----concatMap")
        let childrenHouse : [String : Observable<String>] = [
            "yellow" : Observable.of("alla","bell","soma"),
            "blue" : Observable.of("deny","kalla","justin")
        ]
        Observable.of("yellow","blue").concatMap{ ban in
            childrenHouse[ban] ?? .empty()
        }.subscribe(onNext: {
            print($0)
        }).disposed(by: disposeBag)
        
        print("-----merge1")
        let buk = Observable.from(["강북","성북","동대문","종로"])
        let nam = Observable.from(["강남","강동","영등포","양천"])
    }

}

